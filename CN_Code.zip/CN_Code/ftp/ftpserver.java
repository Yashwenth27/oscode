package ftp;

import java.io.*;
import java.net.*;

public class ftpserver {
    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(5000)) {
            System.out.println("Server is waiting for a connection...");
            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("Connected to " + socket.getInetAddress());
                
                DataInputStream dis = new DataInputStream(socket.getInputStream());
                DataOutputStream dos = new DataOutputStream(socket.getOutputStream());

                String command = dis.readUTF();
                
                if (command.equalsIgnoreCase("upload")) {
                    receiveFile(dis);
                } else if (command.equalsIgnoreCase("download")) {
                    sendFile(dis, dos);
                }

                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void receiveFile(DataInputStream dis) {
        try {
            String fileName = dis.readUTF();
            FileOutputStream fos = new FileOutputStream("ftp/server_directory/" + fileName);
            byte[] buffer = new byte[4096];

            int bytesRead;
            while ((bytesRead = dis.read(buffer)) > 0) {
                fos.write(buffer, 0, bytesRead);
            }

            fos.close();
            System.out.println("File " + fileName + " received successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void sendFile(DataInputStream dis, DataOutputStream dos) {
        try {
            String fileName = dis.readUTF();
            File file = new File("server_directory/" + fileName);
            
            if (file.exists()) {
                FileInputStream fis = new FileInputStream(file);
                byte[] buffer = new byte[4096];

                int bytesRead;
                while ((bytesRead = fis.read(buffer)) > 0) {
                    dos.write(buffer, 0, bytesRead);
                }

                fis.close();
                System.out.println("File " + fileName + " sent successfully.");
            } else {
                dos.writeUTF("File not found");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

