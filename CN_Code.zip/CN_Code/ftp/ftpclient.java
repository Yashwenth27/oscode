package ftp;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class ftpclient {
    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 5000)) {  // Change "localhost" to server IP if needed
            DataInputStream dis = new DataInputStream(socket.getInputStream());
            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter 'upload' to upload a file or 'download' to download a file:");
            String command = scanner.nextLine();
            dos.writeUTF(command);

            if (command.equalsIgnoreCase("upload")) {
                System.out.println("Enter the file path to upload:");
                String filePath = scanner.nextLine();
                uploadFile(filePath, dos);
            } else if (command.equalsIgnoreCase("download")) {
                System.out.println("Enter the file name to download:");
                String fileName = scanner.nextLine();
                dos.writeUTF(fileName);
                downloadFile(fileName, dis);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void uploadFile(String filePath, DataOutputStream dos) {
        try {
            File file = new File(filePath);
            FileInputStream fis = new FileInputStream(file);
            dos.writeUTF(file.getName());

            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) > 0) {
                dos.write(buffer, 0, bytesRead);
            }

            fis.close();
            System.out.println("File uploaded successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void downloadFile(String fileName, DataInputStream dis) {
        try {
            FileOutputStream fos = new FileOutputStream("ftp/client_directory/" + fileName);
            byte[] buffer = new byte[4096];

            int bytesRead;
            while ((bytesRead = dis.read(buffer)) > 0) {
                fos.write(buffer, 0, bytesRead);
            }

            fos.close();
            System.out.println("File downloaded successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
