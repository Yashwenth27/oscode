package rmi;

import java.rmi.Naming;

public class client {
    public static void main(String[] args) {
        try{
            String sname = "rmi://"+args[0]+"/rmserver";
            sinterface intf = (sinterface)Naming.lookup(sname);
            int a = 50;
            int b = 20;
            System.out.println(intf.add(a, b));
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
