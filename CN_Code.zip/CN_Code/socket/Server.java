package socket;
import java.net.*;  
import java.io.*;  
import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*;  

class Server {  
    public static void main(String args[]) throws Exception {  
        JFrame frame = new JFrame("Server");  
        JTextArea textArea = new JTextArea(10, 30);  
        JTextField textField = new JTextField(30);  
        JButton sendButton = new JButton("Send");  

        frame.setLayout(new FlowLayout());  
        frame.add(new JScrollPane(textArea));  
        frame.add(textField);  
        frame.add(sendButton);  
        frame.setSize(400, 300);  
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        frame.setVisible(true);  

        ServerSocket ss = new ServerSocket(3333);  
        Socket s = ss.accept();  
        DataInputStream din = new DataInputStream(s.getInputStream());  
        DataOutputStream dout = new DataOutputStream(s.getOutputStream());  

        sendButton.addActionListener(new ActionListener() {  
            public void actionPerformed(ActionEvent e) {  
                try {  
                    String str2 = textField.getText();
                    textArea.append("Server says: " + str2 + "\n");
                    dout.writeUTF(str2);  
                    dout.flush();  
                    textField.setText("");  
                } catch (IOException ex) {  
                    ex.printStackTrace();  
                }  
            }  
        });  

        String str = "";  
        while (!str.equals("stop")) {  
            str = din.readUTF();  
            textArea.append("Client says: " + str + "\n");  
        }

        din.close();  
        s.close();  
        ss.close();  
    }  
}
