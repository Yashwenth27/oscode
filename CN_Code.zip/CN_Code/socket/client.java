package socket;
import java.net.*;  
import java.io.*;  
import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*;  

class client {  
    public static void main(String args[]) throws Exception {  
        JFrame frame = new JFrame("Client");  
        JTextArea textArea = new JTextArea(10, 30);  
        JTextField textField = new JTextField(30);  
        JButton sendButton = new JButton("Send");  

        frame.setLayout(new FlowLayout());  
        frame.add(new JScrollPane(textArea));  
        frame.add(textField);  
        frame.add(sendButton);  
        frame.setSize(400, 300);  
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        frame.setVisible(true);  

        Socket s = new Socket("localhost", 3333);  
        DataInputStream din = new DataInputStream(s.getInputStream());  
        DataOutputStream dout = new DataOutputStream(s.getOutputStream());  

        sendButton.addActionListener(new ActionListener() {  
            public void actionPerformed(ActionEvent e) {  
                try {  
                    String str = textField.getText();  
                    textArea.append("Client says: " + str + "\n");
                    dout.writeUTF(str);  
                    dout.flush();  
                    textField.setText("");  
                } catch (IOException ex) {  
                    ex.printStackTrace();  
                }  
            }  
        });  

        String str2 = "";  
        while (!str2.equals("stop")) {  
            str2 = din.readUTF();  
            textArea.append("Server says: " + str2 + "\n");  
        }  

        dout.close();  
        s.close();  
    }  
}
