package rmi;

import java.rmi.RemoteException;
import java.rmi.server.*;

public class simple extends UnicastRemoteObject implements sinterface{
    simple() throws RemoteException{};
    @Override
    public int add(int a,int b){
        return a+b;
    }
};
