package rmi;
import java.rmi.*;

public interface sinterface extends Remote{
    int add(int a,int b) throws RemoteException;
} 
