package rmi;

import java.rmi.Naming;

public class server {
    public static void main(String[] args){
        try{
            simple asi = new simple();
            Naming.rebind("rmserver", asi);
            System.out.println("Server started..");
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
